Configuration ContosoWebsite
{
  param ($nodename)
Import-DscResource -ModuleName xWebAdministration

  Node $nodename
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
 	     xWebsite DefaultSite 
        {
            Ensure          = 'Present'
            Name            = 'Default Web Site'
            State           = 'Stopped'
            PhysicalPath    = 'C:\inetpub\wwwroot'
            DependsOn       = '[WindowsFeature]IIS'
        }

 	File WebContent
        {
            Ensure          = 'Present'
          SourcePath      = 'c:\inetpub\wwwroot'
            DestinationPath = 'c:\inetpub\wwwroot'
            Recurse         = $true
            Type            = 'Directory'
          
        }       

        xWebsite NewWebsite
        {
            Ensure          = 'Present'
            Name            = $nodename
            State           = 'Started'
            PhysicalPath    = 'c:\inetpub\wwwroot'
	 BindingInfo     = MSFT_xWebBindingInformation
           	 {
                Protocol              = 'HTTP' 
                Port                  = '80'
                IPAddress             = '10.0.0.5'
               
 
            }
       
        }
    


    }

}
 